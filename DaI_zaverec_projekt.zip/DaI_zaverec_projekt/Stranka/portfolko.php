

<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="Stranka slavky fratricovej" charset="UTF-8">
  <meta name="Author" content="Peter Tibensky, STU"> 
  <meta http-equiv="content-language" content="sk">
   <link rel="stylesheet" href="css/default.css"> 
  <link rel="stylesheet" href="css/layout.css"> 
  <link rel="stylesheet" href="css/media-queries.css"> 
  <link rel="stylesheet" type="text/css" href="style.css">
  <title>SF</title>
    <link rel="shortcut icon" href="favicon.png" >
</head>
<body>



<div class="logo center">
<a href="index.php"><img src="favicon.png" alt='Home' ></a>
</div>

<div class="topnav">
<div class="flex-parent jc-center ">

    <a href='indexx.php' class="button button1 font">texty</a>

    <a href='foto.php' class="button button1 font">foto</a>

    <a href='portfolko.php' class="button button1hover font">portfolko</a>

</div>
 </div>

        <!-- Content left -->
        <div class="content-left font">

          <h2>1/2022</h2>
           <p>Portfólio školkských prác</p>
           <br>

        </div>
        <!-- Content center -->
        <div class="content-center"><iframe src="portfolio.pdf" style=" width: 100%; height:550px;"></iframe></div>




</body>
</html>

