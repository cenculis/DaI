# Bakalárska práca AeroPendulum
LaTeX bachelor's theses at the STU Bratislava. / LaTeX bakalárska práca na STU v Bratislave.
