# [Presentation Starter Template](http://sunore.co.za/)

SUnORE-presentation is a Latex starter template that will help you make a better presentations.

* Source: [http://sunore.co.za/SUnORE-presentation](http://sunore.co.za/SUnORE-presentation)
* Homepage: [http://sunore.co.za/](http://sunore.co.za/)
* Documentation: [http://sunore.co.za/docs/](http://sunore.co.za/blog/)

## Installation

Clone the git repo - `git clone git://github.com/johanjvrens/SUnORE-thesis.git` - or [download it](https://github.com/johanjvrens/SUnORE-presentation/zipball/master) and then rename the directory to the name of your thesis.

SUnORE starter Latex presentation template

<p align="center"><img src="https://raw.githubusercontent.com/johanjvrens/stellenbosch-presentation/master/examples/example_1.png"></p>

links:
https://www.sharelatex.com/blog/2013/08/13/beamer-series-pt1.html  
http://tex.stackexchange.com/questions/12806/guidelines-for-customizing-biblatex-styles  
https://www.sharelatex.com/learn/Beamer#Customizing_your_presentation  
http://tex.stackexchange.com/questions/130464/what-are-structural-elements-customizing-the-mechnism-of-beamer-color-theme  
http://tex.stackexchange.com/questions/38208/beamer-create-own-headline-theme  
http://tex.stackexchange.com/questions/85439/custom-headline-in-latex-beamer
http://www.latex-project.org/lppl.txt
